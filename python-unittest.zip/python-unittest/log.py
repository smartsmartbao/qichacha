# -*- coding: utf-8 -*-

import logging
import threading

from _Parameters import proDir
from datetime import datetime
import os

class log:
    def __init__(self):
        global  resultPath
        '''
        proDir:当前主目录的文件路径
        logPath： log文件路径
        resultPath: result结果文件路径
        '''
        #proDir = readConfig.proDir
        resultPath = os.path.join(proDir, "result")

        if not os.path.exists(resultPath):
            os.mkdir(resultPath)
        # defined test result file name by localtime
        #self.logPath = os.path.join(resultPath, str(datetime.now().strftime("%Y%m%d%H%M%S")))
        #self.logPath = os.path.join(resultPath, str(datetime.now().strftime("%Y%m%d")))
        self.logPath = resultPath
        # create test result file if it doesn't exist
        if not os.path.exists(self.logPath):
            os.mkdir(self.logPath)
        # defined logger
        self.logger = logging.getLogger()
        # defined log level
        self.logger.setLevel(logging.INFO)

        # defined handler
        handler = logging.FileHandler(os.path.join(self.logPath, "output.log"))
        # defined formatter
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        # defined formatter
        handler.setFormatter(formatter)
        # add handler
        self.logger.addHandler(handler)

    def get_logger(self):
        return self.logger

    def get_logpath(self):
        return self.logPath

class MyLog:
    log = None
    mutex = threading.Lock()

    def __init__(self):
        pass

    @staticmethod
    def get_log():
        if MyLog.log is None:
            MyLog.mutex.acquire()
            MyLog.log = log()
            MyLog.mutex.release()

        return MyLog.log

if __name__ == '__main__':
    log=MyLog.get_log()
    test=log.logger
    test.info("---test----")
    test.error("---test1----")