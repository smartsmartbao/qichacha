# -*- coding: utf-8 -*-
import unittest
import HTMLTestRunner
from datetime import datetime
from log import MyLog as Log
from _Parameters import *

unittest.TestCaseLevel.runLevel=caseLevelList

class runAll:
    def __init__(self):
        global resultPath,xmlPath
        self.log = Log.get_log()
        self.logger = self.log.get_logger()
        self.caseListFile=os.path.join(proDir, "caseList.txt")
        resultPath = os.path.join(self.log.get_logpath(), "report.html")
        xmlPath=os.path.join(self.log.get_logpath(), "test-reports")

    def set_case_list(self):
        fb = open(self.caseListFile)
        for value in fb.readlines():
            data = str(value)
            if data != '' and not data.startswith("#"):
                self.caseList.append(data.replace("\n", ""))
        fb.close()

    def set_case_suite(self):
        self.set_case_list()
        test_suite = unittest.TestSuite()
        suite_model = []

        for case in self.caseList:
            case_file = os.path.join(proDir, "TestCase\\")
            case_name = case.split("/")[-1]
            discover = unittest.defaultTestLoader.discover(case_file, pattern=case_name + '.py', top_level_dir=None)
            suite_model.append(discover)

        if len(suite_model) > 0:
            for suite in suite_model:
                for test_name in suite:
                    test_suite.addTest(test_name)
        else:
            return None
        return test_suite

    def run(self):
        try:
            self.caseList=[]
            suit = self.set_case_suite()
            if suit is not None:
                self.logger.info("********TEST START: %s********"%str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                fp = open(resultPath, 'wb')
                #生成HTML格式的报告
                HTMLTestRunner.HTMLTestRunner(stream=fp, title='Test Report:Demo', description='Test description:Demo',verbosity=2).run(suit)

            else:
                self.logger.info("Have no case to test.")
        except Exception as ex:
            self.logger.error(str(ex))
        finally:
            self.logger.info("*********TEST END: %s*********"%str(datetime.now().strftime("%Y-%m-%d %H:%M:%S")))

if __name__ == '__main__':
    ra=runAll()
    ra.run()
    #os.system("pause")

