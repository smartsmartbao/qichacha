# -*- coding: utf-8 -*-
import requests
import json
from log import MyLog as Log
import testlink
from _Parameters import *

log = Log.get_log()
logger = log.get_logger()


'''Common Function'''
#每条用例执行结束，回写到testlink中
def TestlinkInsert(casename,testresult,url=tl_url, key=tl_key, projectname=tl_projectname, testplanname=tl_testplanname, buildname=tl_bulidname):
    myTestLink = testlink.TestlinkAPIClient(url, key)  # 链接testlink
    newProjectID = myTestLink.getTestProjectByName(projectname)['id']
    testplanID = myTestLink.getTestPlanByName(projectname, testplanname)[0]['id']
    if testresult == 'PASS':
        testresult = 'p'
    if testresult == 'FAIL':
        testresult = 'f'
    casename=tl_prefix+casename
    myTestLink.reportTCResult(None, testplanID, buildname, testresult, "", guess=True,testcaseexternalid=casename, platformname="0")
    # 修改test case的 execution type
    myTestLink.setTestCaseExecutionType(casename, 1, newProjectID, 2)


'''Project Function'''
defaultheaders={"Content-Type": "application/json;charset=UTF-8"}

#解析头节点
def parseheaders(headers):
    defaul=json.loads(json.dumps(defaultheaders))
    real=json.loads(json.dumps(headers))

    for key1 in real.keys():
        i=0
        for key2 in defaul.keys():
            if key2 == key1:
                defaultheaders[key2]=real[key1]
            else:
                i=i+1
        if i>len(defaul)-1:
            defaultheaders[key1]=real[key1]
    return defaultheaders

#---登陆，获取UserToken---
def getUserToken(apiUrl,username=None,time=1552543886748,header=defaultheaders):
    '''
    :param apiUrl:
    :param username: 登陆的用户名
    :param time: 时间戳
    :param header: request headers; (格式：{"xxx": xxx})
    :return: response,字典格式
    '''
    api="%sloginName=%s&t=%s"%(apiUrl,username,time)
    try:
        response=requests.get(api)
        response=json.loads(response.content)
        return response
    except Exception as ex:
        logger.error(str(ex))
        return None

#---登陆，获取每一题的信息---
def getTestInfo(apiUrl,testItemid=None,time=1552543886748,header=defaultheaders):
    api="%s&testItemId=%s&t=%s"%(apiUrl,testItemid,time)
    header=parseheaders(header)
    try:
        response=requests.get(api,headers=header)
        rescontext=json.loads(response.content)
        return rescontext
    except Exception as ex:
        logger.error(str(ex))
        return None