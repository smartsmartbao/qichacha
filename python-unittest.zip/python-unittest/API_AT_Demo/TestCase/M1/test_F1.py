# -*- coding: utf-8 -*-
import unittest
from _Keywords import *

# unittest.TestCaseLevel.runLevel=[1,2,3]

class test_F1(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pass

    @classmethod
    def tearDownClass(cls):
        pass

    def setUp(self):
        self.assertEqual(1,1)

    def tearDown(self):
        #print   "test--------------"
        # try:
        #     self.assertEqual(1,1)
        # except AssertionError as e:
        #     self.set_case_result("FAIL")
        testresult= self.get_case_result()
        casename=(self._testMethodName).split("test_case_")[1]
        TestlinkInsert(casename,testresult=testresult)

    @unittest.setLevel(1,"case level 1")
    def test_case_1067(self):
        self.assertEqual(1,2)

    @unittest.setLevel(4,"case level 4")
    def test_case_1068(self):
        self.assertEqual(1,1)

    def test_case_1069(self):
        self.assertEqual(1,1)

    def test_case_1070(self):
        self.assertEqual(1,1)
        TestlinkInsert(1)

if __name__ == '__main__':
    unittest.main()
