# -*- coding: utf-8 -*-
import unittest
from _Keywords import *
from _Parameters import *

class test_F2(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        global tokenID,headers
        headers=tokenID=None
        response=getUserToken(api_login,loginUser)
        try:
            if response['message']=='SUCCESS' or response['message']==u'成功':
                tokenID=response['token']
                headers={"Authorization": tokenID}
        except Exception as ex:
            logger.error(str(ex))

    def setUp(self):
        logger.info("Test Case %s Start!"%self._testMethodName)

    def tearDown(self):
        testresult= self.get_case_result()
        casename=(self._testMethodName).split("test_case_")[1]
        TestlinkInsert(casename,testresult=testresult)
        logger.info("Test Case %s End!"%self._testMethodName)

    def test_case_1066(self):
        response=getTestInfo(api_getTestInfo,testItemid=testid01,header=headers)
        #logger.info(response)
        print response
        checkMsg='How to consider'
        self.assertIn(checkMsg,str(response))

    def test_case_1071(self):
        response=getTestInfo(api_getTestInfo,testItemid=testid02,header=headers)
        #logger.info(response)
        print response
        checkMsg='How to consider'
        self.assertIn(checkMsg,str(response))


if __name__ == '__main__':
    unittest.main()
