# -*- coding: utf-8 -*-
import os

#设置需要跑的case level，若没有则为空 ,如： caseLevelList=[]
caseLevelList=[1,2]

#----TestLink Information-------
tl_url="http://10.119.169.66/testlink/lib/api/xmlrpc/v1/xmlrpc.php"
tl_key="615f68f991035e6d178b2ff108b2ae62"
tl_projectname="test2"
tl_testplanname="KTEC-PRC-IIT-Internal Test Plan"
tl_bulidname="SIT1"
tl_prefix="test2-"

#----Env. Information-------
test_baseurl="http://10.119.169.87:8080"

#----Database Information-------
db_host=""
db_username=""
db_password=""
db_port=""
db_database=""

#Project Path
proDir = os.path.split(os.path.realpath(__file__))[0]

#----test data-------
api_login="%s/login?"%test_baseurl
api_getTestInfo="%s/test/getItemInfo?"%test_baseurl
loginUser="suqiongzhao"
testid01=170
testid02=171
