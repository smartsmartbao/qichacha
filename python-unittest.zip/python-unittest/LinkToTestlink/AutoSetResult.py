#!/usr/bin/python
# -*- coding:utf-8 -*-
from testlink_connect import ConnectTestLink
from log import MyLog as Log
from bs4 import BeautifulSoup
from _Parameters import *

log = Log.get_log()
logger = log.get_logger()

#将结果回写到testlink
def write_result_to_testlink():

    url = tl_url  # testlink API地址
    key = tl_key  # API key,个人设置里面有
    projectname = tl_projectname  # 项目名称
    testplanname = tl_testplanname  # 测试计划名称
    bulidname = tl_bulidname
    reportPath = os.path.join(os.path.join(proDir, "result"), "report.html")

    tlc = ConnectTestLink(url, key, projectname, testplanname)

    caseDic=parseReport(reportPath)

    for testcaseid in caseDic.keys():
        testproess=caseDic[testcaseid]
        try:
            if testcaseid != '${EMPTY}':# 不确定
                if testproess == 'f':
                    tlc.report_test_result(tl_prefix + testcaseid, bulidname, 'f')  # testid包括项目名+number
                    tlc.change_test_executiontype(tl_prefix + testcaseid,1)
                if testproess == 'p':
                    tlc.report_test_result(tl_prefix + testcaseid, bulidname, 'p')  # testid包括项目名+number
                    tlc.change_test_executiontype(tl_prefix + testcaseid,1)
        except Exception as ex:
            print str(ex)
            logger.error(str(ex))

    logger.info("update testlink result successfully!")


#解析report.html
def parseReport(report_path):
    dict={}
    soup=BeautifulSoup(open(report_path),"html.parser")
    body= soup.body #获取body标签内容
    table=body.table #获取body标签中的table标签内容
    tr=table.tr #获取table中第一个tr

    while tr.find_next_sibling("tr") is not None:  #循环遍历 根据tr标签是否有兄弟tr节点
        if "class" in tr.attrs and "id" in tr.attrs:  #tr节点属性有id和class属性就是要找的testcase层
            getCaseid=tr.td.get_text()
            if "test_case_" in getCaseid:
                caseid=getCaseid.split("test_case_")[1]  #获取test case id
                if (tr.attrs["id"]).startswith("pt" ): #判断case result
                    dict[caseid]="p"
                elif (tr.attrs["id"]).startswith("st" ):
                    dict[caseid]="s"
                else:
                    dict[caseid]="f"
        tr=tr.find_next_sibling("tr") #获取下一个兄弟节点
    return dict

if __name__ == '__main__':
    write_result_to_testlink()
    # reportPath = os.path.join(os.path.join(proDir, "result"), "report.html")
    # print parseReport(reportPath)