#!/usr/bin/python
# -*- coding:utf-8 -*-

import testlink

MANUAL = 1
AUTOMATED = 2
HIGH=3
MEDIUM=2
LOW=1

class ConnectTestLink:
    # 初始化对象
    def __init__(self, url, key, projectname, testplanname):
        self.projectname = projectname  # 项目名称
        self.testplanname = testplanname  # 测试计划名称
        self.myTestLink = testlink.TestlinkAPIClient(url, key)  # 链接testlink
        self.newProjectID = self.myTestLink.getTestProjectByName(projectname)['id']
        self.testplanID = self.myTestLink.getTestPlanByName(self.projectname, self.testplanname)[0]['id']

    # 回写执行结果到testlink
    def report_test_result(self, test_case_id, bulid_name, test_result):
        self.myTestLink.reportTCResult(None, self.testplanID, bulid_name, test_result, "", guess=True,
                                       testcaseexternalid=test_case_id, platformname="0")

    # 修改test case的 execution type
    def change_test_executiontype(self, test_case_id, tc_version):
        self.myTestLink.setTestCaseExecutionType(test_case_id, tc_version,
                                                 self.newProjectID, AUTOMATED)
